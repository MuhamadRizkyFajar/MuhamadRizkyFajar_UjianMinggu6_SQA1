package com.juaracoding.shop_demoqa.driver.strategies;

import org.openqa.selenium.WebDriver;

public interface DriverStrategy {
	
	public WebDriver setStrategy();
}
