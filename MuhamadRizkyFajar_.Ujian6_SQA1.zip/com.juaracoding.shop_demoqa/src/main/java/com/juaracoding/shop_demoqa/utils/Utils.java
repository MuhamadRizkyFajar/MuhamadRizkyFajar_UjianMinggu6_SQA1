package com.juaracoding.shop_demoqa.utils;

public class Utils {
	
	public static int testcount=0;
	
}
